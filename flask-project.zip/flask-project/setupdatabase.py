from app import db,FormData

#Creates ALL THE TABLES MODEL --> Db TABLE
db.create_all()
